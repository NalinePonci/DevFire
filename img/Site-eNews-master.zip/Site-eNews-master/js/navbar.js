function aparece() {
    $("#cadastro").show();
}
