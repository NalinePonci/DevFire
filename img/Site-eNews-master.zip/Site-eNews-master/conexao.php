<?php

    $conexao = mysqli_connect('localhost:3306' , 'root' , '1234' , 'esportNews') or die("Erro na conexão");

?>